$(document).ready(function(){
   $("#lions_roar")[0].play();
      setTimeout(function(){
         $("#hidden")[0].click();
      }, 3200);
})
