$(document).ready(function(){
   $("#header").hover(function(){
      $("#greeting")[0].play();
   })
});
